**``To RUN THE APPLICATION ``**

1. INSTALL **Python 3.11.0**

2. CREATE AN ACTIVE VIRTUAL ENVIRONMENT
        **python3 -m venv venv
        . venv/bin/activate**

3. INSTALL REQUIRED PACKAGES 
    **pip install flask**
    **pip install YahooFinancials**


4. EXPORT VARIABLE ON YOUR TERMINAL
   **export FLASK_APP=__init__.py**  
   **export FLASK_DEBUG=true**  

5. INITIALIZE AND FETCH DATA FROM YahooFinancial. RUN COMMAND ON TERMINAL
    **flask init_db**  
 
6. TO RUN THE APPLICATION 
    ***flask run***

7. OPEN ON YOUR BROWSER TO FETCH DATA
    ***http://127.0.0.1:5000/get_all_companies/2022-04-11*** all data for perticular date
    ***http://127.0.0.1:5000/get_all_records_of_company/INTC*** all record of a company
    ***http://127.0.0.1:5000/get_all_records/INTC/2022-04-11***  record of a company for perticular date

8. POST REQUEST TO UPDATE
  **curl -X POST http://127.0.0.1:5000/update_stock_data -H 'Content-Type: application/json' -d '{"close": 46.56999969482422,"company": "INTC","currency": "USD","date": "2022-04-11","high": 47.29999923706055,"low": 46.529998779296875,"open": 46.900001525878906,"volume": 3035}'**

9. UPDATE COMPANY DETAILS INSIDE **config.py** IF REQUIRED AND RE RUN **STEP 6**

**```References```**

https://www.linode.com/docs/guides/create-restful-api-using-python-and-flask/#create-the-list-endpoint-in-flask

https://flask.palletsprojects.com/en/2.0.x/tutorial/database/

https://flask.palletsprojects.com/en/2.0.x/tutorial/factory/

https://pypi.org/project/yahoofinancials/