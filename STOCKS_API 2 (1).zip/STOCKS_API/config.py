FLASK_APP='./flaskr/__init__.py'
COMPANIES=['IBM', 'AAPL', 'MSFT', 'INTC']
SECRET_KEY='dev'