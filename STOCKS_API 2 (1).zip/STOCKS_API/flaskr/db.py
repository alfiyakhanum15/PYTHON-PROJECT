from flask import current_app, g
from flask.cli import with_appcontext
from yahoofinancials import YahooFinancials
import sqlite3
import click

def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(
            current_app.config['DATABASE'],
            detect_types=sqlite3.PARSE_DECLTYPES
        )
        g.db.row_factory = sqlite3.Row

    return g.db


def close_db(e=None):
    db = g.pop('db', None)

    if db is not None:
        db.close()

def init_db():
    db = get_db()

    with current_app.open_resource('schema.sql') as f:
        db.executescript(f.read().decode('utf8'))


@click.command('init-db')
@with_appcontext
def init_db_command():
    """Clear the existing data and create new tables."""
    init_db()
    click.echo('Initialized the database.')
    
    yahoo_financials = YahooFinancials(current_app.config["COMPANIES"]) #TODO Make it as config
    historical_data_of_stocks=yahoo_financials.get_historical_price_data("2022-04-10", "2022-05-30", "daily")
    
    data_to_be_inserted = []

    print("COMPANIES = ", current_app.config["COMPANIES"])
    for company in current_app.config["COMPANIES"]:
        print('processing ', company)
        for prices in historical_data_of_stocks[company]["prices"]:
            data_to_be_inserted.append((company, historical_data_of_stocks[company]["currency"], prices["open"], prices["close"], prices["high"], prices["low"], prices["formatted_date"], prices["volume"]))

    connection = get_db()
    curs = connection.cursor()
    query = "INSERT INTO STOCKS (company, currency, open, close, high, low, date, volume) VALUES (?,?,?,?,?,?,?,?)"
    curs.executemany(query, data_to_be_inserted)
    print("TOTAL INSERTED RECORDS", curs.rowcount)
    connection.commit()      

    click.echo('data is processed')
    

def init_app(app):
    app.teardown_appcontext(close_db)
    app.cli.add_command(init_db_command)
