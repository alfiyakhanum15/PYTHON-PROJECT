from flask import request

def init_routes(app, db):
    # a simple page that says hello
    @app.route('/hello')
    def hello():
        return 'Hello, World!'

    @app.route('/get_all_companies/<date>')
    def get_all_companies(date):     
        connection = db.get_db()
        cursor = connection.cursor()
        cursor.execute("""SELECT * FROM STOCKS WHERE DATE = ?""", (date,))

        rows = cursor.fetchall()   
        return_object = []
        for row in rows: 
            return_object.append({ 
                "company": row['company'], 
                "currency": row['currency'], 
                "open": row['open'],
                "close": row['close'], 
                "high": row['high'], 
                "low": row['low'], 
                "date": row['date'], 
                "volume": row['volume'] 
            })
        return return_object
    
    @app.route('/get_all_records_of_company/<company>')
    def get_all_records_of_company(company):
        connection = db.get_db()
        cursor = connection.cursor()
        cursor.execute("""SELECT * FROM STOCKS WHERE company = ?""", (company, ))

        rows = cursor.fetchall()   
        return_object = []
        for row in rows: 
            return_object.append({ 
                "company": row['company'], 
                "currency": row['currency'], 
                "open": row['open'],
                "close": row['close'], 
                "high": row['high'], 
                "low": row['low'], 
                "date": row['date'], 
                "volume": row['volume'] 
            })
        return return_object


    @app.route('/get_all_records/<company>/<date>')
    def get_all_records(company, date):
        connection = db.get_db()
        cursor = connection.cursor()
        cursor.execute("""SELECT * FROM STOCKS WHERE DATE = ? AND company = ?""", (date, company, ))

        rows = cursor.fetchall()   
        return_object = []
        for row in rows: 
            return_object.append({ 
                "company": row['company'], 
                "currency": row['currency'], 
                "open": row['open'],
                "close": row['close'], 
                "high": row['high'], 
                "low": row['low'], 
                "date": row['date'], 
                "volume": row['volume'] 
            })
        return return_object


    @app.route('/update_stock_data', methods=['POST'])
    def update_stock_data():
        connection = db.get_db()
        cursor = connection.cursor()
        data_to_update = request.get_json(force=True)
        print(data_to_update)
        cursor.execute("UPDATE STOCKS SET \
                       currency = ?, open = ?, close = ?, high = ?, low = ?, volume = ? \
                       WHERE date = ? AND company = ?",\
                        (data_to_update['currency'], data_to_update['open'], data_to_update['close'], data_to_update['high'], data_to_update['low'],data_to_update['volume'], data_to_update['date'], data_to_update['company']))
        updated_record = cursor.rowcount
        print(updated_record)
        connection.commit()   
        return { "updated_record": updated_record }
        
        
