DROP TABLE IF EXISTS STOCKS;

CREATE TABLE STOCKS (
    company TEXT NOT NULL,
    currency TEXT NOT NULL,
    open REAL,
    close REAL,
    high REAL,
    low REAL,
    date TEXT,
    volume INTEGER
)